public class ProjectTest {
        public static void main(String[] args) {
                Employment saloon = new Employment("Barber shop", "sahare", "diploma");
                System.out.println(saloon.toString());
                System.out.println();

                Employer fundi = new Employer("bakari Juma", "Kigamboni", "degree", "pilotbaba08", "0777393032");
                System.out.println(fundi.displayinfo());

                System.out.println();

                Employee Huss = new Employee("Bakari Juma", "kisota", "Masters", "bakju@gmail.com", "0672221255",
                                "BITA/12/12/012/TZ");
                System.out.println(Huss.myinformation());
                System.out.println();

                Salary First = new Salary("Saleh Juma Ali", "Kipangani Wete Penba", "Degree", "0777243848",
                                "rambotrans999",
                                "Normal", 1200000);
                System.out.println(First.getinfo());

                Advertise Kubwa = new Advertise("Accountant", "sahare", "Degree", "pb04@gmail.com", "0623567789",
                                "TAN/5/23",
                                "Socialmedia");
                System.out.println(Kubwa.advertisinginfo());
        }
}