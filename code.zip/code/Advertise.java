public class Advertise extends Employer {
    private String advertising_no;
    private String advertisingsource;

    public Advertise(String name, String address, String educationlevel, String email, String phone_no,
            String advertising_no, String advertisingsource) {
        super(name, address, educationlevel, email, phone_no);
        this.advertising_no = advertising_no;
        this.advertisingsource = advertisingsource;

    }

    public void setadvertising_no(String advertising_no) {
        this.advertising_no = advertising_no;
    }

    public String getadvertising_no() {
        return advertising_no;
    }

    public void setadvertisingsource(String advertisingsource) {
        this.advertisingsource = advertisingsource;
    }

    public String getadvertisingsource() {
        return advertisingsource;
    }

    public String advertisinginfo() {
        return (super.toString() + " advertised on " + getadvertisingsource() + " and has " + getadvertising_no()
                + " as a number of advertise in this year");
    }

}
