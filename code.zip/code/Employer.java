public class Employer extends Employment {
    private String phone_no;
    private String email;

    public Employer(String name, String address, String educationlevel, String email, String phone_no) {
        super(name, address, educationlevel);
        this.email = email;
        this.phone_no = phone_no;
    }

    public void setphone_no(String phone_number) {
        phone_no = phone_number;
    }

    public String getphone_no() {
        return phone_no;
    }

    public void setemail(String e_mail) {
        email = e_mail;
    }

    public String getemail() {
        return email;
    }

    public String displayinfo() {
        return ("My name is " + getname() + " and I am living in " + getaddress() + " also my level of education is "
                + geteducationlevel() + ". Also my telephone number is : " + getphone_no() + " you can find me on "
                + getemail());
    }
}