public class Salary extends Employer {
    private String salarytype;
    private int salatyamount;

    public Salary(String name, String address, String educationlevel, String phone_no, String email, String salarytype,
            int salatyamount) {
        super(name, address, educationlevel, phone_no, email);
        this.salarytype = salarytype;
        this.salatyamount = salatyamount;
    }

    public void setsalarytype(String type) {
        salarytype = type;
    }

    public String getsalarytype() {
        return salarytype;
    }

    public void setsalaryamount(int amount) {
        salatyamount = amount;
    }

    public int getsalaryamount() {
        return salatyamount;
    }

    public String getinfo() {
        return (super.displayinfo() + " I am providing salary in " + getsalarytype() + " type." + " With amount of "
                + getsalaryamount());
    }
}