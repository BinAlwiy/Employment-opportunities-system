public class Employee extends Employer {
    private String id;

    public Employee(String name, String address, String educationlevel, String phone_no, String email, String id) {
        super(name, address, educationlevel, phone_no, email);
        this.id = id;
    }

    public void setid(String id_no) {
        id = id_no;
    }

    public String getid() {
        return id;
    }

    public String myinformation() {
        return (super.displayinfo() + " my id is : " + getid());
    }
}