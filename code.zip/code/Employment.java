public class Employment {
    private String name;
    private String address;
    private String educationlevel;

    public Employment(String name, String address, String educationlevel) {
        this.name = name;
        this.address = address;
        this.educationlevel = educationlevel;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getname() {
        return name;
    }

    public void setaddress(String address) {
        this.address = address;
    }

    public String getaddress() {
        return address;
    }

    public void seteducationlevel(String educationlevel) {
        this.educationlevel = educationlevel;
    }

    public String geteducationlevel() {
        return educationlevel;
    }

    public String toString() {
        return ("There is Employment opportunity called " + getname() + " and is available on " + getaddress()
                + ". For those who have " + geteducationlevel() + " as their level of education.");
    }
}